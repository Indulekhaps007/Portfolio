function openProject(projectFile) {
    window.location.href = projectFile; 
}